import dialog from "./dialog.vue"


export default {
    install(Vue){
        Vue.component('c-dialog',dialog)
    }
}
