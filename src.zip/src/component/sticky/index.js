import sticky from "./sticky.vue"


export default {
    install(Vue){
        Vue.component('c-sticky',sticky)
    }
}
