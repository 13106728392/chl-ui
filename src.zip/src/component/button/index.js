import button from "./button.vue"


export default {
    install(Vue){
        Vue.component('c-button',button)
    }
}
