import input from "./input.vue"


export default {
    install(Vue){
        Vue.component('c-input',input)
    }
}
