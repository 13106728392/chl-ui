import Ctable from "./table.vue"


export default {
    install(Vue){
        Vue.component('Ctable',Ctable)
    }
}
