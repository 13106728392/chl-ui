import icon from "./icon.vue"


export default {
    install(Vue){
        Vue.component('c-icon',icon)
    }
}
