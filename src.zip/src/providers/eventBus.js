import Vue from 'vue'

const vue = new Vue

/***
 * 
 * Event key 集合
 * 
 */
vue.keys = {
    // 在不引入vuex时,统一处理的事件
}

export default vue