import Vue from 'vue'

// 移动box
Vue.directive('dialogDrag', {
  bind(el, binding, vnode, oldVnode) {
 

    const dialogHeaderEl = el.querySelector('.modal-header') || el.querySelector('.dialog-header')  //触摸头部触发方法
    const dragDom = el.querySelector('.outer-modal') ||  el.querySelector('.outer-dialog') // 移动主体

    
    let isFullScreen = false // 初始化非全屏

    dialogHeaderEl.style.cursor = 'move'
    // 获取原有属性 ie dom元素.currentStyle 火狐谷歌 window.getComputedStyle(dom元素, null);
    const sty = dragDom.currentStyle || window.getComputedStyle(dragDom, null)
    dialogHeaderEl.onmousedown = (e) => {
      // 鼠标按下，计算当前元素距离可视区的距离
      const disX = e.clientX - dialogHeaderEl.offsetLeft
      const disY = e.clientY - dialogHeaderEl.offsetTop
      // 获取到的值带px 正则匹配替换
      let styL, styT

      // 注意在ie中 第一次获取到的值为组件自带50% 移动之后赋值为px
      if (sty.left.includes('%')) {
        styL = +document.body.clientWidth * (+sty.left.replace(/\%/g, '') / 100)
        styT = +document.body.clientHeight * (+sty.top.replace(/\%/g, '') / 100)
      } else {
        styL = +sty.left.replace(/\px/g, '')
        styT = +sty.top.replace(/\px/g, '')
      }
      document.onmousemove = function(e) {
        // 通过事件委托，计算移动的距离
        const l = e.clientX - disX
        const t = e.clientY - disY

        // 移动当前元素
        dragDom.style.left = `${l + styL}px`
        dragDom.style.top = `${t + styT}px`

        // 将此时的位置传出去
        // binding.value({x:e.pageX,y:e.pageY})
      }

      document.onmouseup = function(e) {
        document.onmousemove = null
        document.onmouseup = null
      }
    }

    // 双击头部全屏
    dialogHeaderEl.ondblclick = (e)=>{
      if(isFullScreen === false){
        // let nowWidth = dragDom.clientWidth
        // let nowHeight = dragDom.clientHeight 
        // let nowMarginTop = dragDom.style.margintop

        dragDom.style.left = 0
        dragDom.style.top = 0
        dragDom.style.right = 0
        dragDom.style.bttom = 0
        // dragDom.style.height  = '100VH'
        // dragDom.style.width  = '100VW'
        dragDom.style.margin = 0
        debugger

        isFullScreen = true
        dialogHeaderEl.style.cursor = 'initial'
        dialogHeaderEl.onmousedown = null


      }

      // console.log(e)
      // debugger
    }



  }
})