<template>
  <div>
      <h1>按钮  Button</h1>
      <div >
      <c-button type="primary" name="right">正常</c-button>
      <c-button type="info">一般</c-button>
      <c-button type="success">成功</c-button>
      <c-button type="warning">警告</c-button>
      <c-button type="danger">失败</c-button>
      <c-button type="primary" disabled>禁用</c-button>
      </div>
  </div>
</template>

<script>
export default {
    name:' button-view',
    

}
</script>

<style>

</style>